package com.gmail.keseltms.myapp.homework16

class Message(
    val message: String,
    val time: String
)