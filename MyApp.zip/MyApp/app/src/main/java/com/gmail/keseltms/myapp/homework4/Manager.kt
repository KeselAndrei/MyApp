package com.gmail.keseltms.myapp.homework4

class Manager(name: String, salary: Int, var listWorker: MutableList<Worker>) :
    Employee(name, salary)