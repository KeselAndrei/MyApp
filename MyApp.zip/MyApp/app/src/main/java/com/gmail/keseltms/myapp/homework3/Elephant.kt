package com.gmail.keseltms.myapp.homework3

class Elephant(var name: String, speed: Double) : Animal(speed)