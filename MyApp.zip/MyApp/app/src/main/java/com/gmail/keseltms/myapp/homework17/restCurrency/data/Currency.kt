package com.gmail.keseltms.myapp.homework17.restCurrency.data

data class Currency(
    val id: Int,
    val name: String,
    val symbol: String
)