package com.gmail.keseltms.myapp.homework13

object SharedPrefsKeys {

    const val PREFS_KEY = "SHARED_PREFERENCES_UTILS"
    const val PREFS_MESSAGE_BRAND_KEY = "PREFS_MESSAGE_BRAND_KEY"
    const val PREFS_MESSAGE_BARCODE_KEY = "PREFS_MESSAGE_BARCODE_KEY"
    const val DEF_VALUE_BRAND = "НЕИЗВЕСТЕН"
    const val DEF_VALUE_BARCODE = 0L
}