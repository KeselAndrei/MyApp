package com.gmail.keseltms.myapp.homework4

class Boss(name: String, salary: Int, var listManager: MutableList<Manager>) :
    Employee(name, salary)