package com.gmail.keseltms.myapp.homework4

open class Employee(open val name: String, open val salary: Int)